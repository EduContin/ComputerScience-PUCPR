import socket
import sys
import time

HOST = "127.0.0.1"
PORT = 9999

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
    s.bind((HOST, PORT))
except:
    print(f"ERROR: Couldn't bind to {PORT}")
    sys.exit()

s.listen(5)

print(f"Aguardando conexões em {PORT}")

while True:
    conn, addr = s.accept()

    print(f"Recebi uma conexão de {addr}")

    time.sleep(10)
    break

print("O cliente encerrou")
conn.close()