import socket
import sys

HOST = '127.0.0.1' # localhost = esta máquina
PORT = int(input("PORT: ")) # portas abaixo de 1023 exigem permissão de root

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
    s.bind((HOST, PORT))
except:
    print('# erro de bind')
    sys.exit()

s.listen(5)

print('aguardando conexoes em ', PORT)

while True:
    conn, addr = s.accept()

    print('recebi uma conexao de ', addr)

    user = input("Digite um usuário: ")

    while True:
        data = conn.recv(10000)
        print('recebi ', len(data), ' bytes')

        if not data:
            break

        print(data)

conn.close()
print('o cliente encerrou')
