from models import Base
from sqlalchemy.orm import mapped_column, Mapped
from sqlalchemy import int

class Person(Base):
    __tablename__ = "person"