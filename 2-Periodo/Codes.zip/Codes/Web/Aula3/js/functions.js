var valor = document.getElementById("valor").value;

alert(valor);