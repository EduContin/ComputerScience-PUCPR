<?php

    $country = $_POST["country"];

    $response = "";

    switch($country) {
        case "brasil":
            $response = "BRL";
            break;
        case "usa":
            $response = "USD";
            break;
        case "suica":
            $response = "CHF";
            break;

        default:
            $response = "Invalid Country.";
    }

    $json = json_encode($response);

    echo $json;

?>