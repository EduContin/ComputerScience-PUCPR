async function locate_currency() {

    var form = document.getElementById('formulario');
    var data = new FormData(form);

    var promise = await fetch("php/locate_currency.php", {
        method: "POST",
        body: data
    });

    var resposta = await promise.json();

    console.log(resposta);

}