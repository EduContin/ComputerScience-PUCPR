async function registrarMusica() 
{
    var form = document.getElementById('formulario');
    var dados = new FormData(form);
    
    var promise = await fetch("registrarMusica.php", {
        method: "POST",
        body: dados
    });

}
