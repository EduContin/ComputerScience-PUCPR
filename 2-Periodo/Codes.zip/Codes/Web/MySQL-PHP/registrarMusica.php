<?php

    $titulo = $_POST['titulo'];
    $duracao = $_POST['duracao'];
    $nome = $_POST['nome'];
    $album = $_POST['album'];

  $conexao = mysqli_connect("localhost:3306", "root", "root", "web");

  $query = "INSERT INTO musica (titulo, duracao, compositor, album) VALUES ('$titulo', '$duracao', '$nome', '$album')";

  mysqli_query($conexao, $query);

?>