#include <stdio.h>

int main(int argc, char *argv[])
{

    // If args more or no arguments passed, print error
    if (argc != 2)
    {
        printf("Wrong formatting. Usage: %s filename.txt", argv[0]);

        return 0;   
    }
    
    // Pointer to file, vars to storage file content and storage counter
    FILE *file = fopen(argv[1], "r");

    char ch;
    int letterCount[26] = {0};

    if (file)
    {
        while((ch = fgetc(file)) != EOF)
        {
            if (ch >= 'a' && ch <= 'z')
            {
                letterCount[ch - 'a']++;
            }

            else if(ch >= 'A' && ch <= "Z")
            {
                letterCount[ch - 'A']++;
            }
        }

        fclose(file);


        for (int i = 0; i < 26; i++)
        {
            printf("%c = %d\n", (i + 'A'), letterCount[i]);
        }
    }

    // If file is unaccessible, prints error
    else
    {
        printf("Unable to read file. Either empty or unaccessible.");
    
        return 1;
    }

    return 0;
}
