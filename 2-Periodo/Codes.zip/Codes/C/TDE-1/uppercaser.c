#include <stdio.h>
#include <ctype.h>

int main(int argc, char *argv[])
{

    // If args more or no arguments passed, print error
    if (argc != 3)
    {
        printf("Wrong formatting. Usage: %s input.txt output.txt", argv[0]);

        return 0;   
    }
    
    // Pointer to file, vars to storage file content and storage counter
    FILE *file, *file_out;
    file = fopen(argv[1], "r");
    file_out = fopen(argv[2], "w");

    char ch;

    if (file && file_out)
    {
        while((ch = fgetc(file)) != EOF)
        {
            fputc(toupper(ch), file_out);
        }

        printf("Converted sucessfully!\n");
        
        fclose(file);
        fclose(file_out);
    }

    // If file is unaccessible, prints error
    else
    {
        printf("Unable to read file. Either empty or unaccessible.");
    
        return 1;
    }

    return 0;
}
