#include <stdio.h>

typedef struct program
{
    /* data */
    char name[25];
    int year;
    int height;
} person ;


int main()
{
    person persons[4];

    for (int i = 0; i < 4; i++)
    {
        printf("Digite o nome da %d pessoa: \n", i+1);
        fgets(persons[i].name, 25, stdin);

        printf("Digite o ano de nascimento da %d pessoa: \n", i+1);
        scanf_s("%d", &(persons[i].year));

        printf("Digite a altura da %d pessoa: \n", i+1);
        scanf_s("%d", &(persons[i].height));

    }

    for (int i = 0; i < 4; i++)
    {
        printf("Nome da %d° pessoa: %s.\n", i+1, persons[i].name);
        printf("Data de Nascimento da %d° pessoa: %d.\n", i+1, persons[i].year);
        printf("Altura da %d° pessoa: %d.\n", i+1, persons[i].height);
    }
}